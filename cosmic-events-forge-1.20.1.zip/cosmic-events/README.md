# Cosmic Events (Forge 1.20.1)

مود حوادث كونية عشوائية + مخلوق "زائر الفراغ".

## المحتوى
- **نيزك**: يسقط بعد تحذير، يحفر فوهة ويترك `Meteorite Ore` (تعطي `Cosmic Shard`).
- **عاصفة شمسية**: تفتح الجو وتجعله نهاراً، وتولّع أي كائن (واللاعبين) تحت السماء المكشوفة. الحماية: سقف أو ماء.
- **ثقب أسود**: يسحب الكائنات والبلوكات القريبة ويؤذي من يقترب منه ثم يختفي.
- **Void Walker**: يظهر بعد النيزك والثقب الأسود، ينتقل بسرعة، يسقط `Cosmic Shard`، ويختفي وحده.
- تحذير في الشات + صوت + عدّاد في آخر 5 ثواني قبل كل حادثة.

## الأوامر (تحتاج صلاحية OP)
```
/cosmic meteor [now]
/cosmic solar [now]
/cosmic blackhole [now]
/cosmic random [now]
/cosmic voidwalker
/cosmic stop
```
`now` يتخطى التحذير (مفيد للتجربة).

## الحصول على ملف الـ jar بدون كمبيوتر (GitHub)
1. اعمل repository جديد على GitHub وارفع محتوى المجلد كله (بما فيه `.github`).
2. افتح تبويب **Actions** ← **Build mod jar** ← **Run workflow**.
3. بعد ما يخلص (دقيقتين تقريباً) نزّل `cosmicevents-jar` من قسم Artifacts. جواه الـ jar، حطه في مجلد `mods`.

## البناء
1. ثبّت JDK 17.
2. افتح المجلد في IntelliJ IDEA كمشروع Gradle (أو انسخ `gradlew` ومجلد `gradle/` من Forge MDK 1.20.1 إن لم يكونا موجودين).
3. للتجربة: `./gradlew runClient`
4. لبناء الملف: `./gradlew build` ثم خذ الـ jar من `build/libs/`.

## الإعدادات
بعد أول تشغيل: `config/cosmicevents-common.toml` (أو `serverconfig` حسب العالم) فيه مدة الفواصل، زمن التحذير، نصف قطر الفوهة،
تعطيل تدمير البلوكات (`destroyBlocks`)، احتمال ظهور Void Walker، وغيرها.
