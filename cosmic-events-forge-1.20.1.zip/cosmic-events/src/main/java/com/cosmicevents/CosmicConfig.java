package com.cosmicevents;

import net.minecraftforge.common.ForgeConfigSpec;

public final class CosmicConfig {
    public static final ForgeConfigSpec SPEC;

    public static final ForgeConfigSpec.BooleanValue AUTO_EVENTS;
    public static final ForgeConfigSpec.IntValue MIN_MINUTES;
    public static final ForgeConfigSpec.IntValue MAX_MINUTES;
    public static final ForgeConfigSpec.IntValue WARNING_SECONDS;

    public static final ForgeConfigSpec.BooleanValue DESTROY_BLOCKS;
    public static final ForgeConfigSpec.IntValue CRATER_RADIUS;

    public static final ForgeConfigSpec.IntValue SOLAR_STORM_SECONDS;
    public static final ForgeConfigSpec.BooleanValue BURN_PLAYERS;

    public static final ForgeConfigSpec.IntValue BLACK_HOLE_SECONDS;
    public static final ForgeConfigSpec.IntValue BLACK_HOLE_RADIUS;

    public static final ForgeConfigSpec.DoubleValue VOID_WALKER_CHANCE;
    public static final ForgeConfigSpec.IntValue VOID_WALKER_LIFETIME_SECONDS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.push("scheduler");
        AUTO_EVENTS = b.comment("Run cosmic events automatically at random times (Overworld only).")
                .define("autoEvents", true);
        MIN_MINUTES = b.comment("Minimum minutes between automatic events.")
                .defineInRange("minMinutesBetweenEvents", 20, 1, 100000);
        MAX_MINUTES = b.comment("Maximum minutes between automatic events.")
                .defineInRange("maxMinutesBetweenEvents", 45, 1, 100000);
        WARNING_SECONDS = b.comment("Seconds of warning (chat + sound + countdown) before an event begins.")
                .defineInRange("warningSeconds", 10, 0, 300);
        b.pop();

        b.push("griefing");
        DESTROY_BLOCKS = b.comment("If false, meteors and black holes do not change any blocks (meteors then drop shards as items).")
                .define("destroyBlocks", true);
        CRATER_RADIUS = b.comment("Meteor crater radius in blocks.")
                .defineInRange("craterRadius", 5, 2, 16);
        b.pop();

        b.push("solarStorm");
        SOLAR_STORM_SECONDS = b.comment("Duration of a solar storm.")
                .defineInRange("durationSeconds", 60, 5, 3600);
        BURN_PLAYERS = b.comment("Also set players on fire when they stand under open sky.")
                .define("burnPlayers", true);
        b.pop();

        b.push("blackHole");
        BLACK_HOLE_SECONDS = b.comment("Duration of a black hole.")
                .defineInRange("durationSeconds", 12, 3, 300);
        BLACK_HOLE_RADIUS = b.comment("Pull radius in blocks.")
                .defineInRange("pullRadius", 24, 6, 64);
        b.pop();

        b.push("voidWalker");
        VOID_WALKER_CHANCE = b.comment("Chance that Void Walkers appear after a meteor or black hole.")
                .defineInRange("spawnChance", 0.6D, 0.0D, 1.0D);
        VOID_WALKER_LIFETIME_SECONDS = b.comment("How long event-spawned Void Walkers live before vanishing.")
                .defineInRange("lifetimeSeconds", 180, 10, 3600);
        b.pop();

        SPEC = b.build();
    }

    private CosmicConfig() {}
}
