package com.cosmicevents;

import com.cosmicevents.registry.ModBlocks;
import com.cosmicevents.registry.ModEntities;
import com.cosmicevents.registry.ModItems;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(CosmicEvents.MODID)
public class CosmicEvents {
    public static final String MODID = "cosmicevents";

    public CosmicEvents() {
        IEventBus modBus = FMLJavaModLoadingContext.get().getModEventBus();
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModLoadingContext.get().registerConfig(ModConfig.Type.COMMON, CosmicConfig.SPEC);
    }
}
