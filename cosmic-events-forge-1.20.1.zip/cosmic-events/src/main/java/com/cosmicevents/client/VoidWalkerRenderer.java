package com.cosmicevents.client;

import com.cosmicevents.CosmicEvents;
import com.cosmicevents.entity.VoidWalkerEntity;
import net.minecraft.client.model.EndermanModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.client.renderer.entity.layers.EyesLayer;
import net.minecraft.resources.ResourceLocation;

public class VoidWalkerRenderer extends MobRenderer<VoidWalkerEntity, EndermanModel<VoidWalkerEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(CosmicEvents.MODID, "textures/entity/void_walker.png");
    private static final ResourceLocation EYES =
            new ResourceLocation(CosmicEvents.MODID, "textures/entity/void_walker_eyes.png");

    public VoidWalkerRenderer(EntityRendererProvider.Context context) {
        super(context, new EndermanModel<>(context.bakeLayer(ModelLayers.ENDERMAN)), 0.5F);
        this.addLayer(new EyesLayer<VoidWalkerEntity, EndermanModel<VoidWalkerEntity>>(this) {
            @Override
            public RenderType renderType() {
                return RenderType.eyes(EYES);
            }
        });
    }

    @Override
    public ResourceLocation getTextureLocation(VoidWalkerEntity entity) {
        return TEXTURE;
    }
}
