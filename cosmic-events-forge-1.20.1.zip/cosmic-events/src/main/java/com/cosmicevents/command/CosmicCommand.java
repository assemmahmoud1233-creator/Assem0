package com.cosmicevents.command;

import com.cosmicevents.CosmicConfig;
import com.cosmicevents.CosmicEvents;
import com.cosmicevents.entity.VoidWalkerEntity;
import com.cosmicevents.event.CosmicEventManager;
import com.cosmicevents.event.CosmicEventType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.util.List;

/**
 * /cosmic meteor|solar|blackhole [now]   - trigger one event (with "now" the warning is skipped)
 * /cosmic random [now]                   - trigger a random event
 * /cosmic voidwalker                     - spawn a Void Walker near you
 * /cosmic stop                           - cancel all running events
 */
@Mod.EventBusSubscriber(modid = CosmicEvents.MODID)
public final class CosmicCommand {

    @SubscribeEvent
    public static void onRegisterCommands(RegisterCommandsEvent event) {
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("cosmic")
                .requires(source -> source.hasPermission(2));

        for (CosmicEventType type : CosmicEventType.values()) {
            root.then(Commands.literal(type.id)
                    .executes(ctx -> run(ctx.getSource(), type, false))
                    .then(Commands.literal("now").executes(ctx -> run(ctx.getSource(), type, true))));
        }
        root.then(Commands.literal("random")
                .executes(ctx -> run(ctx.getSource(), null, false))
                .then(Commands.literal("now").executes(ctx -> run(ctx.getSource(), null, true))));
        root.then(Commands.literal("voidwalker").executes(ctx -> spawnWalker(ctx.getSource())));
        root.then(Commands.literal("stop").executes(ctx -> stop(ctx.getSource())));

        event.getDispatcher().register(root);
    }

    private static int run(CommandSourceStack source, CosmicEventType type, boolean instant) {
        ServerLevel level = source.getLevel();
        if (level.dimension() != Level.OVERWORLD) {
            source.sendFailure(Component.translatable("commands.cosmicevents.overworld_only"));
            return 0;
        }
        ServerPlayer focus = source.getPlayer();
        if (focus == null) {
            List<ServerPlayer> players = level.players();
            if (players.isEmpty()) {
                source.sendFailure(Component.translatable("commands.cosmicevents.no_players"));
                return 0;
            }
            focus = players.get(level.getRandom().nextInt(players.size()));
        }

        CosmicEventType chosen = type;
        if (chosen == null) {
            chosen = CosmicEventManager.startRandom(level, focus, instant);
        } else {
            CosmicEventManager.start(level, chosen, focus, instant);
        }
        String name = chosen.id;
        source.sendSuccess(() -> Component.translatable("commands.cosmicevents.started", name), true);
        return 1;
    }

    private static int spawnWalker(CommandSourceStack source) {
        ServerLevel level = source.getLevel();
        boolean ok = VoidWalkerEntity.spawnNear(level, BlockPos.containing(source.getPosition()), 6, 12,
                CosmicConfig.VOID_WALKER_LIFETIME_SECONDS.get() * 20);
        if (!ok) {
            source.sendFailure(Component.translatable("commands.cosmicevents.walker_failed"));
            return 0;
        }
        source.sendSuccess(() -> Component.translatable("commands.cosmicevents.walker_spawned"), true);
        return 1;
    }

    private static int stop(CommandSourceStack source) {
        int count = CosmicEventManager.stopAll();
        source.sendSuccess(() -> Component.translatable("commands.cosmicevents.stopped", count), true);
        return count;
    }

    private CosmicCommand() {}
}
