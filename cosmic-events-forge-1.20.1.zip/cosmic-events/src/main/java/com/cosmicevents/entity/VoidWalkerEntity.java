package com.cosmicevents.entity;

import com.cosmicevents.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.pathfinder.BlockPathTypes;

/**
 * Tall, dark creature with violet eyes. Blinks around much faster than an Enderman
 * and vanishes on its own once its lifetime (set by cosmic events) runs out.
 */
public class VoidWalkerEntity extends Monster {
    /** Ticks left to live; -1 means it never expires (e.g. spawned from an egg). */
    private int lifeLeft = -1;
    private int blinkCooldown = 40;

    public VoidWalkerEntity(EntityType<? extends VoidWalkerEntity> type, Level level) {
        super(type, level);
        this.xpReward = 20;
        this.setPathfindingMalus(BlockPathTypes.WATER, -1.0F);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 50.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.32D)
                .add(Attributes.ATTACK_DAMAGE, 7.0D)
                .add(Attributes.FOLLOW_RANGE, 48.0D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 0.5D);
    }

    public void setLifetime(int ticks) {
        this.lifeLeft = ticks;
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new MeleeAttackGoal(this, 1.1D, false));
        this.goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.8D));
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 16.0F));
        this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    @Override
    public void aiStep() {
        if (this.level().isClientSide) {
            for (int i = 0; i < 2; ++i) {
                this.level().addParticle(ParticleTypes.PORTAL,
                        this.getRandomX(0.5D), this.getRandomY() - 0.25D, this.getRandomZ(0.5D),
                        (this.random.nextDouble() - 0.5D) * 2.0D, -this.random.nextDouble(),
                        (this.random.nextDouble() - 0.5D) * 2.0D);
            }
        } else if (this.isAlive()) {
            tickServerLogic();
        }
        if (this.isRemoved()) {
            return;
        }
        super.aiStep();
    }

    private void tickServerLogic() {
        if (lifeLeft > 0 && --lifeLeft == 0) {
            vanish();
            return;
        }
        if (blinkCooldown > 0) {
            blinkCooldown--;
        }
        LivingEntity target = this.getTarget();
        if (target != null && blinkCooldown <= 0) {
            double distSq = this.distanceToSqr(target);
            boolean far = distSq > 36.0D && distSq < 48.0D * 48.0D;
            boolean ambush = distSq <= 36.0D && this.random.nextInt(50) == 0;
            if (far || ambush) {
                blinkCooldown = blinkNear(target) ? 25 + this.random.nextInt(25) : 10;
            }
        } else if (target == null && blinkCooldown <= 0 && this.random.nextInt(250) == 0) {
            blink(getX() + (random.nextDouble() - 0.5D) * 24.0D, getY(), getZ() + (random.nextDouble() - 0.5D) * 24.0D);
            blinkCooldown = 60;
        }
    }

    private boolean blinkNear(LivingEntity target) {
        for (int i = 0; i < 12; i++) {
            double angle = this.random.nextDouble() * Math.PI * 2.0D;
            double radius = 2.5D + this.random.nextDouble() * 1.5D;
            double x = target.getX() + Math.cos(angle) * radius;
            double z = target.getZ() + Math.sin(angle) * radius;
            if (blink(x, target.getY(), z)) {
                return true;
            }
        }
        return false;
    }

    private boolean blink(double x, double y, double z) {
        double ox = getX();
        double oy = getY();
        double oz = getZ();
        if (this.randomTeleport(x, y, z, true)) {
            this.level().playSound(null, ox, oy, oz, SoundEvents.ENDERMAN_TELEPORT, this.getSoundSource(), 1.0F, 0.6F);
            this.playSound(SoundEvents.ENDERMAN_TELEPORT, 1.0F, 0.6F);
            return true;
        }
        return false;
    }

    private void vanish() {
        if (this.level() instanceof ServerLevel server) {
            server.sendParticles(ParticleTypes.REVERSE_PORTAL, getX(), getY() + 1.4D, getZ(), 40, 0.4D, 0.9D, 0.4D, 0.1D);
            server.playSound(null, getX(), getY(), getZ(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 1.0F, 0.4F);
        }
        this.discard();
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (this.isInvulnerableTo(source)) {
            return false;
        }
        if (!this.level().isClientSide && source.is(DamageTypeTags.IS_PROJECTILE) && this.random.nextFloat() < 0.5F) {
            for (int i = 0; i < 8; i++) {
                if (blink(getX() + (random.nextDouble() - 0.5D) * 16.0D,
                        getY() + random.nextInt(8) - 4,
                        getZ() + (random.nextDouble() - 0.5D) * 16.0D)) {
                    break;
                }
            }
            return false;
        }
        return super.hurt(source, amount);
    }

    @Override
    protected float getStandingEyeHeight(Pose pose, EntityDimensions dimensions) {
        return 2.55F;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENDERMAN_AMBIENT;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource source) {
        return SoundEvents.ENDERMAN_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENDERMAN_DEATH;
    }

    @Override
    public float getVoicePitch() {
        return super.getVoicePitch() * 0.65F;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("LifeLeft", lifeLeft);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        lifeLeft = tag.contains("LifeLeft") ? tag.getInt("LifeLeft") : -1;
    }

    /** Spawns one Void Walker on the surface at a random spot between minDist and maxDist from {@code around}. */
    public static boolean spawnNear(ServerLevel level, BlockPos around, int minDist, int maxDist, int lifetimeTicks) {
        RandomSource rand = level.getRandom();
        for (int i = 0; i < 16; i++) {
            double angle = rand.nextDouble() * Math.PI * 2.0D;
            double dist = minDist + rand.nextDouble() * Math.max(1, maxDist - minDist);
            BlockPos xz = new BlockPos((int) (around.getX() + Math.cos(angle) * dist), 0,
                    (int) (around.getZ() + Math.sin(angle) * dist));
            if (!level.hasChunkAt(xz)) {
                continue;
            }
            BlockPos ground = level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, xz);
            VoidWalkerEntity walker = ModEntities.VOID_WALKER.get().create(level);
            if (walker == null) {
                return false;
            }
            walker.moveTo(ground.getX() + 0.5D, ground.getY(), ground.getZ() + 0.5D, rand.nextFloat() * 360.0F, 0.0F);
            if (!level.noCollision(walker) || level.containsAnyLiquid(walker.getBoundingBox())) {
                continue;
            }
            walker.finalizeSpawn(level, level.getCurrentDifficultyAt(ground), MobSpawnType.EVENT, null, null);
            walker.setLifetime(lifetimeTicks);
            level.addFreshEntity(walker);
            level.sendParticles(ParticleTypes.REVERSE_PORTAL, walker.getX(), walker.getY() + 1.4D, walker.getZ(),
                    40, 0.4D, 0.9D, 0.4D, 0.1D);
            level.playSound(null, ground, SoundEvents.ENDERMAN_TELEPORT, SoundSource.HOSTILE, 1.5F, 0.5F);
            return true;
        }
        return false;
    }
}
