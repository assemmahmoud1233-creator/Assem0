package com.cosmicevents.registry;

import com.cosmicevents.CosmicEvents;
import com.cosmicevents.entity.VoidWalkerEntity;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, CosmicEvents.MODID);

    public static final RegistryObject<EntityType<VoidWalkerEntity>> VOID_WALKER = ENTITIES.register("void_walker",
            () -> EntityType.Builder.of(VoidWalkerEntity::new, MobCategory.MONSTER)
                    .sized(0.6F, 2.9F)
                    .clientTrackingRange(10)
                    .build(new ResourceLocation(CosmicEvents.MODID, "void_walker").toString()));

    private ModEntities() {}
}
