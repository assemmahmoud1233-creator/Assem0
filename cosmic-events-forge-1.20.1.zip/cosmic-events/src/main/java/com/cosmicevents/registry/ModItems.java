package com.cosmicevents.registry;

import com.cosmicevents.CosmicEvents;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, CosmicEvents.MODID);

    public static final RegistryObject<Item> COSMIC_SHARD = ITEMS.register("cosmic_shard",
            () -> new Item(new Item.Properties().rarity(Rarity.RARE)) {
                @Override
                public boolean isFoil(ItemStack stack) {
                    return true;
                }
            });

    public static final RegistryObject<Item> METEORITE_ORE = ITEMS.register("meteorite_ore",
            () -> new BlockItem(ModBlocks.METEORITE_ORE.get(), new Item.Properties()));

    public static final RegistryObject<Item> VOID_WALKER_SPAWN_EGG = ITEMS.register("void_walker_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.VOID_WALKER, 0x0B0B1A, 0xB000FF, new Item.Properties()));

    private ModItems() {}
}
