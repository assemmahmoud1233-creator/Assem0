package com.cosmicevents.event;

import com.cosmicevents.CosmicConfig;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;

public class SolarStormEvent extends CosmicEvent {
    private int ticksLeft = CosmicConfig.SOLAR_STORM_SECONDS.get() * 20;
    private int age;

    public SolarStormEvent(ServerLevel level, ServerPlayer focus, int warnTicks) {
        super(level, focus, warnTicks);
    }

    @Override
    protected void onWarning() {
        EventUtil.broadcast(level, Component.translatable("cosmicevents.warning.solar_storm", warnSeconds())
                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        EventUtil.warningSound(level);
    }

    @Override
    protected void onStart() {
        clearSkyAndMakeDay();
        EventUtil.broadcast(level, Component.translatable("cosmicevents.solar_storm.start")
                .withStyle(ChatFormatting.RED, ChatFormatting.BOLD));
        for (ServerPlayer player : level.players()) {
            player.playNotifySound(SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.MASTER, 0.6F, 0.5F);
        }
    }

    @Override
    protected boolean runTick() {
        age++;
        ticksLeft--;

        if (age % 100 == 0 && (level.isRaining() || level.isThundering())) {
            clearSkyAndMakeDay();
        }
        if (age % 20 == 0) {
            burnExposedCreatures();
        }
        if (age % 10 == 0) {
            for (ServerPlayer player : level.players()) {
                EventUtil.particles(level, ParticleTypes.FLAME, player.getX(), player.getY() + 7.0D, player.getZ(),
                        12, 10.0D, 3.0D, 10.0D, 0.0D);
            }
        }
        if (age % 60 == 0) {
            for (ServerPlayer player : level.players()) {
                player.playNotifySound(SoundEvents.FIRE_AMBIENT, SoundSource.AMBIENT, 1.0F, 0.6F);
            }
        }

        if (ticksLeft <= 0) {
            EventUtil.broadcast(level, Component.translatable("cosmicevents.solar_storm.end")
                    .withStyle(ChatFormatting.YELLOW));
            return true;
        }
        return false;
    }

    private void clearSkyAndMakeDay() {
        level.setWeatherParameters(ticksLeft + 600, 0, false, false);
        long time = level.getDayTime();
        long timeOfDay = time % 24000L;
        if (timeOfDay >= 12500L) {
            level.setDayTime(time - timeOfDay + 24000L + 6000L);
        }
    }

    private void burnExposedCreatures() {
        boolean burnPlayers = CosmicConfig.BURN_PLAYERS.get();
        for (ServerPlayer nearPlayer : level.players()) {
            if (nearPlayer.isSpectator()) {
                continue;
            }
            for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class,
                    nearPlayer.getBoundingBox().inflate(48.0D))) {
                if (!entity.isAlive() || entity.fireImmune() || entity.isInWaterRainOrBubble()) {
                    continue;
                }
                if (entity instanceof Player player && (!burnPlayers || player.isCreative() || player.isSpectator())) {
                    continue;
                }
                BlockPos eyePos = BlockPos.containing(entity.getX(), entity.getEyeY(), entity.getZ());
                if (level.canSeeSky(eyePos)) {
                    entity.setSecondsOnFire(4);
                }
            }
        }
    }
}
