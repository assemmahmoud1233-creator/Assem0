package com.cosmicevents.event;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.Heightmap;

public final class EventUtil {

    public static void broadcast(ServerLevel level, Component message) {
        for (ServerPlayer player : level.players()) {
            player.sendSystemMessage(message);
        }
    }

    public static void actionBar(ServerLevel level, Component message) {
        for (ServerPlayer player : level.players()) {
            player.displayClientMessage(message, true);
        }
    }

    public static void warningSound(ServerLevel level) {
        for (ServerPlayer player : level.players()) {
            player.playNotifySound(SoundEvents.ENDER_DRAGON_GROWL, SoundSource.MASTER, 0.7F, 0.6F);
        }
    }

    /** Sends particles to every player within 160 blocks (vanilla only reaches 32). */
    public static <T extends ParticleOptions> void particles(ServerLevel level, T type, double x, double y, double z,
                                                             int count, double dx, double dy, double dz, double speed) {
        for (ServerPlayer player : level.players()) {
            if (player.distanceToSqr(x, y, z) <= 160.0D * 160.0D) {
                level.sendParticles(player, type, true, x, y, z, count, dx, dy, dz, speed);
            }
        }
    }

    /** A surface position between min and max blocks away from origin (in a loaded chunk). */
    public static BlockPos pickAround(ServerLevel level, BlockPos origin, int min, int max, RandomSource random) {
        for (int i = 0; i < 10; i++) {
            double angle = random.nextDouble() * Math.PI * 2.0D;
            double dist = min + random.nextDouble() * (max - min);
            BlockPos xz = new BlockPos((int) (origin.getX() + Math.cos(angle) * dist), 0,
                    (int) (origin.getZ() + Math.sin(angle) * dist));
            if (level.hasChunkAt(xz)) {
                return level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, xz);
            }
        }
        return level.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, origin);
    }

    private EventUtil() {}
}
