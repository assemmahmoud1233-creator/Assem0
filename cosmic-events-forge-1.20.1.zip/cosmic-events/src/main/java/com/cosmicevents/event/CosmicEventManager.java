package com.cosmicevents.event;

import com.cosmicevents.CosmicConfig;
import com.cosmicevents.CosmicEvents;
import com.mojang.logging.LogUtils;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Ticks active events and schedules random ones. State lives in memory only. */
@Mod.EventBusSubscriber(modid = CosmicEvents.MODID)
public final class CosmicEventManager {
    private static final Logger LOGGER = LogUtils.getLogger();
    private static final List<CosmicEvent> ACTIVE = new ArrayList<>();
    private static long nextAutoEvent = -1L;

    public static void start(ServerLevel level, CosmicEventType type, ServerPlayer focus, boolean instant) {
        int warnTicks = instant ? 0 : CosmicConfig.WARNING_SECONDS.get() * 20;
        CosmicEvent event = type.create(level, focus, warnTicks);
        ACTIVE.add(event);
        event.begin();
    }

    public static CosmicEventType startRandom(ServerLevel level, ServerPlayer focus, boolean instant) {
        CosmicEventType[] types = CosmicEventType.values();
        CosmicEventType type = types[level.getRandom().nextInt(types.length)];
        start(level, type, focus, instant);
        return type;
    }

    /** @return how many events were stopped. */
    public static int stopAll() {
        int count = ACTIVE.size();
        for (CosmicEvent event : ACTIVE) {
            event.cancel();
        }
        ACTIVE.clear();
        return count;
    }

    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) {
            return;
        }
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) {
            return;
        }

        Iterator<CosmicEvent> iterator = ACTIVE.iterator();
        while (iterator.hasNext()) {
            CosmicEvent active = iterator.next();
            try {
                if (active.tick()) {
                    iterator.remove();
                }
            } catch (Exception e) {
                LOGGER.error("Cosmic event crashed and was cancelled", e);
                active.cancel();
                iterator.remove();
            }
        }

        if (!CosmicConfig.AUTO_EVENTS.get()) {
            return;
        }
        ServerLevel overworld = server.overworld();
        long now = overworld.getGameTime();
        if (nextAutoEvent < 0L) {
            scheduleNext(overworld, now);
            return;
        }
        if (now < nextAutoEvent) {
            return;
        }
        if (!ACTIVE.isEmpty()) {
            nextAutoEvent = now + 200L;
            return;
        }
        List<ServerPlayer> players = new ArrayList<>();
        for (ServerPlayer player : overworld.players()) {
            if (!player.isSpectator()) {
                players.add(player);
            }
        }
        if (players.isEmpty()) {
            nextAutoEvent = now + 1200L;
            return;
        }
        RandomSource random = overworld.getRandom();
        startRandom(overworld, players.get(random.nextInt(players.size())), false);
        scheduleNext(overworld, now);
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        stopAll();
        nextAutoEvent = -1L;
    }

    private static void scheduleNext(ServerLevel level, long now) {
        int min = CosmicConfig.MIN_MINUTES.get();
        int max = Math.max(min, CosmicConfig.MAX_MINUTES.get());
        int minutes = min + level.getRandom().nextInt(max - min + 1);
        nextAutoEvent = now + minutes * 1200L;
    }

    private CosmicEventManager() {}
}
