package com.cosmicevents.event;

import com.cosmicevents.CosmicConfig;
import com.cosmicevents.entity.VoidWalkerEntity;
import com.cosmicevents.registry.ModBlocks;
import com.cosmicevents.registry.ModItems;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

public class MeteorEvent extends CosmicEvent {
    private static final int FALL_TICKS = 70;

    private final BlockPos impact;
    private final Vec3 start;
    private final Vec3 end;
    private int fallTick;

    public MeteorEvent(ServerLevel level, ServerPlayer focus, int warnTicks) {
        super(level, focus, warnTicks);
        this.impact = EventUtil.pickAround(level, focus.blockPosition(), 28, 64, random);
        double angle = random.nextDouble() * Math.PI * 2.0D;
        this.end = new Vec3(impact.getX() + 0.5D, impact.getY(), impact.getZ() + 0.5D);
        this.start = end.add(Math.cos(angle) * 55.0D, 120.0D, Math.sin(angle) * 55.0D);
    }

    @Override
    protected void onWarning() {
        EventUtil.broadcast(level, Component.translatable("cosmicevents.warning.meteor", warnSeconds())
                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
        EventUtil.warningSound(level);
    }

    @Override
    protected void onStart() {
        EventUtil.actionBar(level, Component.translatable("cosmicevents.meteor.incoming").withStyle(ChatFormatting.RED));
    }

    @Override
    protected boolean runTick() {
        fallTick++;
        Vec3 pos = start.lerp(end, fallTick / (double) FALL_TICKS);
        EventUtil.particles(level, ParticleTypes.FLAME, pos.x, pos.y, pos.z, 30, 1.0D, 1.0D, 1.0D, 0.05D);
        EventUtil.particles(level, ParticleTypes.LARGE_SMOKE, pos.x, pos.y, pos.z, 10, 1.2D, 1.2D, 1.2D, 0.02D);
        EventUtil.particles(level, ParticleTypes.LAVA, pos.x, pos.y, pos.z, 4, 0.6D, 0.6D, 0.6D, 0.0D);
        if (fallTick % 8 == 0) {
            level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.FIRECHARGE_USE, SoundSource.AMBIENT, 6.0F, 0.5F);
        }
        if (fallTick >= FALL_TICKS) {
            impact();
            return true;
        }
        return false;
    }

    private void impact() {
        int radius = CosmicConfig.CRATER_RADIUS.get();
        BlockPos center = impact.above();
        double cx = center.getX() + 0.5D;
        double cy = center.getY();
        double cz = center.getZ() + 0.5D;

        if (CosmicConfig.DESTROY_BLOCKS.get()) {
            carveCrater(center, radius);
        } else {
            int shards = 3 + random.nextInt(4);
            level.addFreshEntity(new ItemEntity(level, cx, cy + 1.0D, cz,
                    new ItemStack(ModItems.COSMIC_SHARD.get(), shards)));
        }

        level.playSound(null, cx, cy, cz, SoundEvents.GENERIC_EXPLODE, SoundSource.BLOCKS, 12.0F, 0.6F);
        EventUtil.particles(level, ParticleTypes.EXPLOSION_EMITTER, cx, cy + 1.0D, cz, 3, 2.0D, 1.0D, 2.0D, 0.0D);
        EventUtil.particles(level, ParticleTypes.FLASH, cx, cy + 1.0D, cz, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        EventUtil.particles(level, ParticleTypes.LAVA, cx, cy + 1.0D, cz, 60, 3.0D, 2.0D, 3.0D, 0.0D);

        double range = radius + 7.0D;
        Vec3 origin = new Vec3(cx, cy, cz);
        for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, new AABB(origin, origin).inflate(range))) {
            double dist = Math.sqrt(entity.distanceToSqr(cx, cy, cz));
            if (dist > range) {
                continue;
            }
            double falloff = 1.0D - dist / range;
            entity.hurt(level.damageSources().explosion(null, null), (float) (4.0D + 22.0D * falloff));
            if (dist < radius + 3.0D) {
                entity.setSecondsOnFire(6);
            }
            Vec3 push = entity.position().subtract(origin).normalize().scale(1.2D * falloff).add(0.0D, 0.5D * falloff, 0.0D);
            entity.setDeltaMovement(entity.getDeltaMovement().add(push));
            entity.hurtMarked = true;
        }

        if (random.nextDouble() < CosmicConfig.VOID_WALKER_CHANCE.get()) {
            int count = 1 + random.nextInt(2);
            int lifetime = CosmicConfig.VOID_WALKER_LIFETIME_SECONDS.get() * 20;
            boolean any = false;
            for (int i = 0; i < count; i++) {
                any |= VoidWalkerEntity.spawnNear(level, center, 6, 12, lifetime);
            }
            if (any) {
                for (ServerPlayer player : level.players()) {
                    if (player.distanceToSqr(cx, cy, cz) < 100.0D * 100.0D) {
                        player.displayClientMessage(Component.translatable("cosmicevents.meteor.walker")
                                .withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.ITALIC), true);
                    }
                }
            }
        }
    }

    private void carveCrater(BlockPos center, int radius) {
        double outer = radius + 0.5D;
        double inner = outer - 1.6D;
        for (int dx = -radius - 1; dx <= radius + 1; dx++) {
            for (int dy = -radius - 1; dy <= radius + 1; dy++) {
                for (int dz = -radius - 1; dz <= radius + 1; dz++) {
                    double d2 = dx * dx + dy * dy + dz * dz;
                    if (d2 > outer * outer) {
                        continue;
                    }
                    BlockPos pos = center.offset(dx, dy, dz);
                    BlockState old = level.getBlockState(pos);
                    if (old.isAir() || old.getDestroySpeed(level, pos) < 0.0F) {
                        continue;
                    }
                    if (dy <= 0 && d2 >= inner * inner) {
                        level.setBlock(pos, pickShellBlock(), 3);
                    } else {
                        level.setBlock(pos, Blocks.AIR.defaultBlockState(), 3);
                    }
                }
            }
        }
        level.setBlock(center.below(radius), ModBlocks.METEORITE_ORE.get().defaultBlockState(), 3);
    }

    private BlockState pickShellBlock() {
        float roll = random.nextFloat();
        if (roll < 0.09F) {
            return ModBlocks.METEORITE_ORE.get().defaultBlockState();
        } else if (roll < 0.28F) {
            return Blocks.MAGMA_BLOCK.defaultBlockState();
        } else if (roll < 0.36F) {
            return Blocks.CRYING_OBSIDIAN.defaultBlockState();
        }
        return Blocks.BLACKSTONE.defaultBlockState();
    }
}
