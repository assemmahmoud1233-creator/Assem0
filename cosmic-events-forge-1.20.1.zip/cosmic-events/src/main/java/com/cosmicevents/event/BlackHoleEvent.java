package com.cosmicevents.event;

import com.cosmicevents.CosmicConfig;
import com.cosmicevents.entity.VoidWalkerEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.FallingBlockEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

public class BlackHoleEvent extends CosmicEvent {
    private final Vec3 center;
    private final int radius = CosmicConfig.BLACK_HOLE_RADIUS.get();
    private final List<FallingBlockEntity> flung = new ArrayList<>();
    private int ticksLeft = CosmicConfig.BLACK_HOLE_SECONDS.get() * 20;
    private int age;

    public BlackHoleEvent(ServerLevel level, ServerPlayer focus, int warnTicks) {
        super(level, focus, warnTicks);
        BlockPos ground = EventUtil.pickAround(level, focus.blockPosition(), 18, 36, random);
        this.center = new Vec3(ground.getX() + 0.5D, ground.getY() + 5.0D, ground.getZ() + 0.5D);
    }

    @Override
    protected void onWarning() {
        EventUtil.broadcast(level, Component.translatable("cosmicevents.warning.black_hole", warnSeconds())
                .withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD));
        EventUtil.warningSound(level);
    }

    @Override
    protected void onStart() {
        level.playSound(null, center.x, center.y, center.z, SoundEvents.END_PORTAL_SPAWN, SoundSource.AMBIENT, 6.0F, 0.6F);
        EventUtil.particles(level, ParticleTypes.FLASH, center.x, center.y, center.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        EventUtil.actionBar(level, Component.translatable("cosmicevents.black_hole.start")
                .withStyle(ChatFormatting.DARK_PURPLE));
    }

    @Override
    protected boolean runTick() {
        age++;
        ticksLeft--;

        visuals();
        if (age % 20 == 1) {
            level.playSound(null, center.x, center.y, center.z, SoundEvents.PORTAL_AMBIENT, SoundSource.AMBIENT, 6.0F, 0.5F);
        }

        AABB box = new AABB(center, center).inflate(radius);
        for (Entity entity : level.getEntities((Entity) null, box, this::pullable)) {
            pull(entity);
        }

        if (CosmicConfig.DESTROY_BLOCKS.get() && age % 2 == 0) {
            tearBlocks();
        }
        if (age % 20 == 0) {
            flung.removeIf(Entity::isRemoved);
        }

        if (ticksLeft <= 0) {
            collapse();
            return true;
        }
        return false;
    }

    @Override
    protected void onCancel() {
        release();
    }

    private boolean pullable(Entity entity) {
        return entity.isAlive() && !entity.isSpectator() && !(entity instanceof VoidWalkerEntity)
                && (entity instanceof LivingEntity || entity instanceof ItemEntity || entity instanceof FallingBlockEntity);
    }

    private void pull(Entity entity) {
        Vec3 toCenter = center.subtract(entity.getX(), entity.getY() + entity.getBbHeight() * 0.5D, entity.getZ());
        double dist = Math.max(toCenter.length(), 0.01D);
        double frac = 1.0D - Math.min(dist, radius) / radius;
        double speed = Math.min(0.05D + 0.50D * frac * frac, dist);
        Vec3 dir = toCenter.scale(1.0D / dist);
        Vec3 swirl = new Vec3(-dir.z, 0.0D, dir.x).scale(0.06D * frac + 0.01D);

        entity.setDeltaMovement(dir.scale(speed).add(swirl));
        entity.hurtMarked = true;
        entity.fallDistance = 0.0F;

        if (dist < 2.5D && entity instanceof LivingEntity living && age % 5 == 0) {
            living.hurt(level.damageSources().magic(), 4.0F);
        } else if (dist < 1.8D && CosmicConfig.DESTROY_BLOCKS.get()
                && (entity instanceof ItemEntity || entity instanceof FallingBlockEntity)) {
            EventUtil.particles(level, ParticleTypes.PORTAL, entity.getX(), entity.getY(), entity.getZ(), 6, 0.2D, 0.2D, 0.2D, 0.2D);
            entity.discard();
        }
    }

    private void tearBlocks() {
        double tearRadius = Math.min(radius * 0.5D, 9.0D);
        for (int i = 0; i < 10 && flung.size() < 160; i++) {
            double dx = (random.nextDouble() * 2.0D - 1.0D) * tearRadius;
            double dy = (random.nextDouble() * 2.0D - 1.0D) * tearRadius;
            double dz = (random.nextDouble() * 2.0D - 1.0D) * tearRadius;
            if (dx * dx + dy * dy + dz * dz > tearRadius * tearRadius) {
                continue;
            }
            BlockPos pos = BlockPos.containing(center.x + dx, center.y + dy, center.z + dz);
            if (!level.hasChunkAt(pos)) {
                continue;
            }
            BlockState state = level.getBlockState(pos);
            if (state.isAir() || state.hasBlockEntity() || !state.getFluidState().isEmpty()) {
                continue;
            }
            float hardness = state.getDestroySpeed(level, pos);
            if (hardness < 0.0F || hardness > 20.0F) {
                continue;
            }
            FallingBlockEntity block = FallingBlockEntity.fall(level, pos, state);
            block.dropItem = false;
            block.setNoGravity(true);
            flung.add(block);
        }
    }

    private void visuals() {
        double base = age * 0.35D;
        for (int k = 0; k < 6; k++) {
            double angle = base + k * (Math.PI * 2.0D / 6.0D);
            double ring = 2.2D + 0.4D * Math.sin(age * 0.2D + k);
            EventUtil.particles(level, ParticleTypes.FLAME,
                    center.x + Math.cos(angle) * ring,
                    center.y + Math.sin(angle) * 0.5D,
                    center.z + Math.sin(angle) * ring,
                    1, 0.0D, 0.0D, 0.0D, 0.0D);
        }
        EventUtil.particles(level, ParticleTypes.SQUID_INK, center.x, center.y, center.z, 2, 0.3D, 0.3D, 0.3D, 0.0D);

        if (age % 2 == 0) {
            for (int i = 0; i < 8; i++) {
                double angle = random.nextDouble() * Math.PI * 2.0D;
                double r = radius * (0.3D + random.nextDouble() * 0.4D);
                double px = center.x + Math.cos(angle) * r;
                double py = center.y + (random.nextDouble() - 0.5D) * r * 0.6D;
                double pz = center.z + Math.sin(angle) * r;
                EventUtil.particles(level, ParticleTypes.PORTAL, px, py, pz, 0,
                        center.x - px, center.y - py, center.z - pz, 1.0D);
            }
        }
    }

    private void collapse() {
        EventUtil.particles(level, ParticleTypes.FLASH, center.x, center.y, center.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        EventUtil.particles(level, ParticleTypes.EXPLOSION_EMITTER, center.x, center.y, center.z, 1, 0.0D, 0.0D, 0.0D, 0.0D);
        EventUtil.particles(level, ParticleTypes.REVERSE_PORTAL, center.x, center.y, center.z, 120, 1.0D, 1.0D, 1.0D, 0.8D);
        level.playSound(null, center.x, center.y, center.z, SoundEvents.GENERIC_EXPLODE, SoundSource.AMBIENT, 8.0F, 0.5F);
        release();

        for (LivingEntity living : level.getEntitiesOfClass(LivingEntity.class, new AABB(center, center).inflate(12.0D))) {
            if (living.isSpectator()) {
                continue;
            }
            Vec3 away = living.position().subtract(center).normalize().scale(0.9D).add(0.0D, 0.5D, 0.0D);
            living.setDeltaMovement(away);
            living.hurtMarked = true;
        }

        EventUtil.broadcast(level, Component.translatable("cosmicevents.black_hole.end")
                .withStyle(ChatFormatting.LIGHT_PURPLE));

        if (random.nextDouble() < CosmicConfig.VOID_WALKER_CHANCE.get()) {
            VoidWalkerEntity.spawnNear(level, BlockPos.containing(center), 3, 8,
                    CosmicConfig.VOID_WALKER_LIFETIME_SECONDS.get() * 20);
        }
    }

    /** Lets any still-floating torn blocks fall back down. */
    private void release() {
        for (FallingBlockEntity block : flung) {
            if (!block.isRemoved()) {
                block.setNoGravity(false);
            }
        }
        flung.clear();
    }
}
