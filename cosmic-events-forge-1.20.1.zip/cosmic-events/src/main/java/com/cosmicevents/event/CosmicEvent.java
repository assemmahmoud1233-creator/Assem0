package com.cosmicevents.event;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;

/** Base class: a warning phase (chat, sound, countdown) followed by the event itself. */
public abstract class CosmicEvent {
    protected final ServerLevel level;
    protected final ServerPlayer focus;
    protected final RandomSource random;

    private final int warnTicks;
    private int warnLeft;
    private boolean started;

    protected CosmicEvent(ServerLevel level, ServerPlayer focus, int warnTicks) {
        this.level = level;
        this.focus = focus;
        this.random = level.getRandom();
        this.warnTicks = warnTicks;
        this.warnLeft = warnTicks;
    }

    protected final int warnSeconds() {
        return Math.max(1, warnTicks / 20);
    }

    /** Called once right after creation. */
    public final void begin() {
        if (warnTicks > 0) {
            onWarning();
        }
    }

    /** @return true when the event is finished and can be removed. */
    public final boolean tick() {
        if (!started) {
            if (warnLeft > 0) {
                if (warnLeft % 20 == 0 && warnLeft / 20 <= 5) {
                    EventUtil.actionBar(level, Component.translatable("cosmicevents.countdown", warnLeft / 20)
                            .withStyle(ChatFormatting.RED));
                }
                warnLeft--;
                return false;
            }
            started = true;
            onStart();
        }
        return runTick();
    }

    public final void cancel() {
        onCancel();
    }

    protected abstract void onWarning();

    protected abstract void onStart();

    protected abstract boolean runTick();

    protected void onCancel() {}
}
