package com.cosmicevents.event;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;

public enum CosmicEventType {
    METEOR("meteor", MeteorEvent::new),
    SOLAR_STORM("solar", SolarStormEvent::new),
    BLACK_HOLE("blackhole", BlackHoleEvent::new);

    public interface Factory {
        CosmicEvent create(ServerLevel level, ServerPlayer focus, int warnTicks);
    }

    public final String id;
    private final Factory factory;

    CosmicEventType(String id, Factory factory) {
        this.id = id;
        this.factory = factory;
    }

    public CosmicEvent create(ServerLevel level, ServerPlayer focus, int warnTicks) {
        return factory.create(level, focus, warnTicks);
    }
}
